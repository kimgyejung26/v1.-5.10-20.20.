import numpy as np
import cv2
import os

########## KNN CODE ############
def distance(v1, v2):
    return np.sqrt(((v1 - v2) ** 2).sum())

def knn(train, test, k=5):
    dist = []
    for i in range(train.shape[0]):
        ix = train[i, :-1]
        iy = train[i, -1]
        d = distance(test, ix)
        dist.append([d, iy])
    dk = sorted(dist, key=lambda x: x[0])[:k]
    labels = np.array(dk)[:, -1]
    output = np.unique(labels, return_counts=True)
    index = np.argmax(output[1])
    return output[0][index]
################################

# ✅ Load Haar Cascade from OpenCV's default path
face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_alt.xml"
)

# ✅ Load Dataset (.npy 파일들이 들어 있는 폴더)
dataset_path = "/Users/rlatjgus_shk/Downloads/SKYST/face_dataset"
face_data = []
labels = []
class_id = 0
names = {}

# 각 .npy 파일을 불러와 하나의 학습 데이터로 구성
for fx in os.listdir(dataset_path):
    if fx.endswith('.npy'):
        names[class_id] = fx[:-4]  # 파일 이름 = 사람 이름
        data_item = np.load(os.path.join(dataset_path, fx))
        face_data.append(data_item)
        target = class_id * np.ones((data_item.shape[0],))
        labels.append(target)
        class_id += 1

face_dataset = np.concatenate(face_data, axis=0)
face_labels = np.concatenate(labels, axis=0).reshape((-1, 1))
trainset = np.concatenate((face_dataset, face_labels), axis=1)

############### 얼굴 인식 함수 ################
def recognize_faces_in_image(image_path):
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("이미지를 불러올 수 없습니다. 경로를 확인하세요.")

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)

    for face in faces:
        x, y, w, h = face
        offset = 10
        face_section = img[y-offset:y+h+offset, x-offset:x+w+offset]
        face_section = cv2.resize(face_section, (100, 100))

        out = knn(trainset, face_section.flatten())
        name = names[int(out)]

        cv2.putText(img, name, (x, y - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
        cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)

    return img  # 이름과 박스가 표시된 이미지 반환

############### 실행 예시 ################
if __name__ == "__main__":
    # ✅ 여기에서 얼굴을 인식할 테스트 이미지 경로 설정
    test_image_path = "/Users/rlatjgus_shk/Downloads/SKYST/IMG_7716.JPG"

    result_img = recognize_faces_in_image(test_image_path)
    cv2.imshow("Face Recognition Result", result_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
