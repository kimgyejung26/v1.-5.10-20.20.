import cv2
import numpy as np 
import os

cap = cv2.VideoCapture(0)
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_alt.xml")  # 수정됨 ✅

skip = 0
face_data = []
dataset_path = "./face_dataset/"

file_name = input("이름(관계)를 입력해주세요 : ")

if not os.path.exists(dataset_path):
	os.makedirs(dataset_path)

while True:
	ret, frame = cap.read()

	if not ret or frame is None:
		print("카메라 프레임을 읽지 못했습니다.")
		continue

	gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

	faces = face_cascade.detectMultiScale(gray_frame, 1.3, 5)
	if len(faces) == 0:
		continue

	faces = sorted(faces, key=lambda x: x[2]*x[3], reverse=True)
	skip += 1

	for i, face in enumerate(faces[:1]):
		x, y, w, h = face

		offset = 10
		face_offset = frame[y-offset:y+h+offset, x-offset:x+w+offset]
		face_selection = cv2.resize(face_offset, (100, 100))

		if skip % 10 == 0:
			face_data.append(face_selection)
			print(f"Collected samples: {len(face_data)}")

		cv2.imshow("Face", face_selection)
		cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

	cv2.imshow("Video Feed", frame)

	key_pressed = cv2.waitKey(1) & 0xFF
	if key_pressed == ord('q'):
		break

face_data = np.array(face_data)
face_data = face_data.reshape((face_data.shape[0], -1))

np.save(os.path.join(dataset_path, file_name + ".npy"), face_data)
print("Dataset saved at:", os.path.join(dataset_path, file_name + ".npy"))

cap.release()
cv2.destroyAllWindows()
